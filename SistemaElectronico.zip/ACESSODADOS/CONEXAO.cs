﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACESSODADOS
{
    public class CONEXAO
    {
        public static string Cn = "Data Source=MIGUEL;Initial Catalog=BD_Advogado;Integrated Security=True";
        //public static string Cn = "Data Source=GCMTI;Initial Catalog=BD_Advogado;User ID=sa;Password=Primavera123";

        ////CONEXAO para o servidor
        //public static string Cn = "Data Source=192.168.1.2;Initial Catalog=DB_PORTAL_SUPORTE_SOLUCAO;User ID=sa;Password=Primavera123";
    }
}
