create proc SP_Ver_Dados_pela_Inflacao 'Agress�o F�sica'
@textobuscar varchar(50)
as
select t1.Descricao as [Infla��o], t2.Descricao as [Artigo], t2.Descricao as [Lei], Multa  from tb_inflacao as t1
join Tb_Artigo as t2 on t2.Id_Inflacao=t1.Id_Inflacao
join tb_Lei_Codigo as t3 on t3.Id_Artigo=t2.Id_Artigo
join tb_Sancoes as t4 on t4.Id_Sancoes=t3.Id_Sancoes
join tb_Tipo_Sancoes as t5 on t5.Id_Tipo_sancoes=t4.Id_Tipo_sancoes
join tb_Multa as t6 on t6.Id_Multa=t5.Id_Multa
where t1.Descricao=@textobuscar

select *from tb_Sancoes
select *from tb_Lei_Codigo
select *from tb_artigo
select *from tb_Multa
select *from tb_Tipo_Sancoes
select *from tb_tipo_lei_codigo
select *from tb_inflacao

insert into tb_Sancoes values ('Lei Rodoviaria', 1,1,1)
insert into Tb_Artigo values ('Lei da Familia', 2,1,1)
insert into tb_Sancoes values ('Desacato as autoridades', 1, 1)
insert into tb_Lei_Codigo values ('Lei 111', 5, 2, 2)
insert into Tb_Artigo values ('Artigo 116�',5)
