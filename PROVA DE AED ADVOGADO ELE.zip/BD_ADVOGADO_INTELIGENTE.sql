CREATE DATABASE BD_Advogado
use BD_Advogado

Go

Create table tb_inflacao
(
Id_Inflacao int primary key identity (1,1),
Descricao Varchar (80)
)

Go
Create table tb_Multa
(
Id_Multa int primary Key identity (1,1),
Multa Varchar (50),
)

Go
Create table tb_Tipo_Lei_Codigo
(
Id_Tipo_Lei_Codigo int primary key identity (1,1),
Nome_Tipo_Lei_Codigo Varchar (50),
)
Go

Create table tb_Tipo_Sancoes
(
Id_Tipo_sancoes int primary key identity (1,1),
Descricao Varchar (50),
Id_Multa int,
Constraint FK_Multa foreign key (Id_Multa) References tb_Multa(Id_Multa)

)

Go 
Create table Tb_Artigo
(
Id_Artigo int primary key identity (1,1),
Descricao Varchar (50),
Id_Inflacao int,
Constraint FK_Art_Infla foreign key (Id_Inflacao) References tb_Inflacao(Id_Inflacao)
)
Go
Create table tb_Sancoes 
(
Id_Sancoes int primary key identity (1,1),
Descricao Varchar (50),
Id_Tipo_Lei_Codigo int,
Id_Tipo_sancoes int,
Constraint FK_T_Lei_Cod foreign key (Id_Tipo_Lei_Codigo) References tb_Tipo_Lei_Codigo (Id_Tipo_Lei_Codigo),
Constraint FK_Tipo_Sancoes foreign key (Id_Tipo_sancoes) References tb_Tipo_Sancoes (Id_Tipo_sancoes)
)

Go
Create table tb_Lei_Codigo
(
Id_Lei_Codigo int primary key identity (1,1),
Descricao Varchar (50),
Id_Artigo int,
Id_Sancoes int,
Id_Tipo_Lei_Codigo int,
Constraint FK_Art foreign key (Id_Artigo) References tb_Artigo(Id_Artigo),
Constraint FK_Arti_anflan foreign key (Id_Sancoes) References tb_Sancoes (Id_Sancoes),
Constraint FK__Tip_Lei_Cod foreign key (Id_Tipo_Lei_Codigo) References tb_Tipo_Lei_Codigo(Id_Tipo_Lei_Codigo)
)